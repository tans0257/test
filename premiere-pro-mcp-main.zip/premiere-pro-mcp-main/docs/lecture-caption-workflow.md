# Guided lecture-caption workflow

## Status

`create_caption_track` now has a `plan_lecture_workflow` action that parses a
caller-provided SRT or VTT locally and returns a timing-correction preview plus
a review checklist. It does not write the artifact, upload it, import it into
Premiere, or call an AI/provider service.

Use this when a long lecture, interview, or training recording has an existing
caption artifact and an editor needs to distinguish a constant offset from a
duration mismatch before importing it.

## Plan a timing review

Provide the artifact content, its syntax, and only the timing observations an
editor has already made:

```json
{
  "action": "plan_lecture_workflow",
  "artifact_format": "srt",
  "caption_content": "<caller-owned SRT content>",
  "target_duration_seconds": 1620,
  "observed_offset_seconds": 0.4,
  "timing_tolerance_seconds": 0.25
}
```

`observed_offset_seconds` is positive when captions currently appear later
than intended. The response contains cue count, first/last timing, a beginning/
middle/end sample, and one of these review-only outcomes:

| Status | Meaning |
| --- | --- |
| `aligned` | No requested correction is needed within the tolerance. |
| `constant_offset` | A safe inverse shift is proposed from the editor-observed offset. |
| `proportional_drift` | A bounded scale preview is proposed only after the caller sets `allow_proportional_scaling: true`. |
| `review_required` | The artifact is invalid, its mismatch is ambiguous, its first cue is not safely anchored, or the proposed operation could create negative time. |

The tool rejects malformed timecodes, non-positive cue ranges, overlaps, more
than 10,000 cues, and overly large artifacts. It deliberately withholds a
proportional correction by default: a caption file ending before a sequence
does not prove drift, because a recording can contain intentional lead-in or
tail time.

## Apply only after review

The plan does not authorize a mutation. Follow its steps separately:

1. Work in a duplicate/test sequence. Use a documented UXP clone workflow only
   when the connected host advertises it; otherwise duplicate in Premiere and
   re-query its stable sequence ID.
2. Review the sampled ranges and update the caller-owned SRT/VTT outside this
   server if the editor accepts a correction.
3. Import the reviewed artifact into the project, then call
   `create_caption_track` with `action: "import"`, the imported `item_id`, and
   an intentional `start_seconds` value.
4. Call `read_sequence_captions` for structural track readback.
5. Play the beginning/middle/end ranges in Premiere. For a rendered check,
   export a short range with `export_sequence` and a preset that burns captions
   into video. Still-frame exports can omit caption tracks on recent releases.
6. Treat final rendered output review as a separate delivery gate.

## Evidence boundary

| Evidence | What it establishes | What it does not establish |
| --- | --- | --- |
| Local timing plan | SRT/VTT syntax, non-overlap, supplied timing assumptions, and a deterministic preview | That any caption file was changed or that Premiere agrees with the plan |
| Caption-track readback | A host-exposed structural track result | Synchronization in playback, line breaks, safe area, or accessibility quality |
| Burn-in range export | A sampled rendered artifact with captions | Temporal playback behavior or full delivery quality |
| Playback/render review | A human-reviewed output at its stated scope | General compatibility for all Premiere, client, or caption versions |

The workflow is a guide and returns `not_run` for structural, playback, and
rendered-output verification until the editor performs and records those steps
on the actual host.

## Export visibility and reversal

Caption tracks render in `export_sequence` by default. CEP cannot remove or
hide them, and deleting the imported SRT/VTT project item does not remove its
caption track. Retire an old track in Premiere or hide it through a capable UXP
panel before importing a replacement, so stale captions do not render twice.

The import result includes `undoSteps` and `reversal`. A usable observed count
comes with exact `multiple_undo` arguments, including `expected_undo_stack_index`.
Use them only immediately, before other edits, and inspect the track afterwards.
The experimental QE count measures the project-wide undo stack; its position alone does not prove
which action is on top or that native caption reversal succeeded. A null count
means no usable count was captured, not zero steps. Never guess a count to undo:
that can reverse an earlier edit.

When a connected UXP panel advertises caption-track mute support, identify the
new track and call `manage_track_state_uxp` with `action: "inspect"`,
`media_type: "caption"` and its exact `track_indices`. Then use `action:
"set_mute"`, `muted: true`, a fresh `operation_id` and the unchanged
`expected_sequence_id` / `expected_muted` values returned by inspection. Read the
mute state back. Muting hides a track; it does not delete it. Export/render review
remains a separate verification step.
