## What does this PR do?

Brief description of the changes and motivation.

## Related Issue

Closes #

## Type of Change

- [ ] New tool(s)
- [ ] Bug fix
- [ ] Documentation
- [ ] Refactor
- [ ] Other

## New Tools Added (if any)

| Tool Name | Module | Description |
|-----------|--------|-------------|
| | | |

**Total tool count after this PR:** (update `release-metadata.json` when changed)

## Checklist

- [ ] `npm run build` compiles without errors
- [ ] Tool descriptions are clear and useful for an LLM
- [ ] All parameters have descriptions
- [ ] ExtendScript uses ES3 syntax (`var`, no arrow functions, no `let`/`const`)
- [ ] User-provided strings are escaped with `escapeForExtendScript()`
- [ ] New module is exported from `getXTools()` and registered in `server.ts`
- [ ] No duplicate tool names introduced
- [ ] Tested with Premiere Pro (if possible)
- [ ] `RESEARCH.md` updated (if adding new tools)

## Compatibility and evidence

- Backend and minimum host version:
- Structural readback / artifact / temporal evidence:
- Live Premiere verification performed (host/version/fixture), or explicitly not run:
- Unknown outcomes, cancellation and recovery limitations:
- Exact checks run (`npm run check`, coverage when applicable):
