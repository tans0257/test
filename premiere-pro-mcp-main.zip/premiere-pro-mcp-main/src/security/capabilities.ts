import { randomUUID } from "node:crypto";

export const CAPABILITIES = ["inspect", "edit", "export", "filesystem", "unsafe-script"] as const;

export type Capability = (typeof CAPABILITIES)[number];

export interface CapabilityConfig {
  capabilities: ReadonlySet<Capability>;
  source: "default" | "environment" | "explicit";
}

const KNOWN = new Set<string>(CAPABILITIES);

/**
 * Resolve the server's authority. Unsafe scripting is deliberately never part
 * of the default: an operator must name it explicitly.
 */
export function resolveCapabilities(
  value: string | undefined = process.env.PREMIERE_MCP_CAPABILITIES,
): CapabilityConfig {
  if (value === undefined || value.trim() === "") {
    return { capabilities: new Set<Capability>(["inspect", "edit", "export", "filesystem"]), source: "default" };
  }

  const capabilities = new Set<Capability>();
  for (const raw of value.split(",")) {
    const name = raw.trim().toLowerCase();
    if (!name) continue;
    if (!KNOWN.has(name)) {
      throw new Error(`Unknown Premiere MCP capability: ${name}`);
    }
    capabilities.add(name as Capability);
  }
  return { capabilities, source: "environment" };
}

export class CapabilityDeniedError extends Error {
  readonly code = "CAPABILITY_DENIED";

  constructor(readonly capability: Capability, readonly operationId: string) {
    super(`Operation ${operationId} requires the '${capability}' capability`);
    this.name = "CapabilityDeniedError";
  }
}

export function requireCapability(
  config: CapabilityConfig,
  capability: Capability,
  operationId: string,
): void {
  if (!config.capabilities.has(capability)) {
    throw new CapabilityDeniedError(capability, operationId);
  }
}

export const UNSAFE_TOOL_NAMES = new Set(["execute_extendscript", "send_raw_script", "evaluate_expression"]);

const INSPECT_TOOL_NAMES = new Set([
  "ping",
  "can_execute",
  "get_operation_performance",
  "inspect_workflow_job",
  "wait_workflow_job",
  "inspect_operation_recovery",
  // Local-only: stores the session guard in server memory, sends nothing to Premiere.
  "set_session_guard",
  "convert_timeline_time",
  "predict_timeline_edit",
  "verify_timeline_postconditions",
  "map_keyframe_time_domain",
  "plan_media_synchronization",
  "map_word_timeline_occurrences",
  "plan_music_remix",
  "plan_scene_segments",
  "verify_caption_render_evidence",
  "bind_media_provenance",
  "preview_extended_edit_plan",
  "preview_stacked_camera_edit",
  "preview_otio_snapshot_export",
  "plan_audio_post_turnover",
  "get_capabilities",
  // Read-only queries whose names miss the read prefixes.
  "has_proxy",
  "is_work_area_enabled",
  "verify_premiere_connection",
  "match_frame",
  "preview_edit_plan",
  "preview_transcript_edit_uxp",
  "plan_transcript_rough_cut_uxp",
  "create_context_edit_plan",
  "create_editorial_context_pack",
  "create_editorial_plan",
  "preview_editorial_plan",
  "preview_project_intake",
  "preview_motion_graphics_demo",
  "preview_product_spot",
  "preview_brand_spot",
  "inspect_sequence_timing_uxp",
  "inspect_sequence_timing_by_guid_uxp",
  "inspect_frame_alignment_uxp",
  "calculate_tick_time_uxp",
  "validate_project_for_export",
  "read_sequence_captions",
  "plan_silence_review_markers",
  "analyze_dialogue_edit_candidates",
  "review_dialogue_candidates",
  "review_quote_paper_edit",
  "review_text_changes",
  "review_sync_evidence",
  "review_broll_placements",
  "preview_derived_dialogue_sequence_uxp",
  "plan_platform_delivery_matrix",
  "validate_platform_publish_package",
  "plan_filler_word_removal",
  "plan_pause_tightening",
  "plan_word_mute_ranges",
  "detect_repeated_takes",
  "check_caption_safe_zone",
  "retime_caption_file",
  "rank_short_form_candidates",
  "plan_chapter_markers",
  "plan_emphasis_zoom_keyframes",
  "plan_beat_montage",
  "plan_cross_app_workflow",
  "plan_speaker_checkerboard",
  "plan_active_speaker_reframe",
  "plan_reaction_captions",
  "plan_short_subscribe_cta",
  "plan_short_export_folder",
  "diff_sequence_snapshots",
  "audit_timeline_health",
  "plan_client_notes_checklist",
  "plan_multicam_angle_switches",
  "compute_mask_fit_motion",
  "map_source_ranges_to_timeline",
]);
// detect_silence reads a media file from disk and shells out to ffmpeg. It
// changes nothing in Premiere, so classifying it as "edit" would overstate what
// it does; filesystem is the authority it actually needs.
const FILESYSTEM_TOOL_NAMES = new Set([
  "preview_mogrt_recipe",
  "verify_mogrt_artifact",
  "apply_lut",
  "verify_delivery_file",
  "verify_delivery_conformance",
  "detect_silence",
  "detect_beats",
  "create_project_backup",
  "analyze_loudness",
  "analyze_video_qc",
  "detect_source_scene_changes",
  "normalize_loudness_file",
  "inspect_media_streams",
  "generate_media_contact_sheet",
  "detect_audio_transients",
  "detect_motion_peaks",
  "read_video_scopes",
  "plan_shot_match",
  "analyze_video_interlacing",
  "detect_active_picture_bounds",
  "inspect_cmx3600_edl",
  "validate_cmx3600_edl",
  "compare_cmx3600_edls",
  "inspect_fcpxml_interchange",
  "verify_fcpxml_media_references",
  "search_workflow_recipes",
  "preview_workflow_recipe",
  "manage_media_watch",
  "preview_watched_media_import",
  "build_caption_artifact",
]);

// These tools have deliberately mixed authority requirements that cannot be
// inferred safely from their names. Keep them explicit: a preview reads an
// approved folder, authoring mutates a saved AE project and exports a file.
const TOOL_CAPABILITY_REQUIREMENTS: Readonly<Record<string, readonly Capability[]>> = {
  execute_extendscript: ["edit", "export", "filesystem", "unsafe-script"],
  send_raw_script: ["edit", "export", "filesystem", "unsafe-script"],
  evaluate_expression: ["edit", "export", "filesystem", "unsafe-script"],
  search_project_context: ["inspect", "filesystem"],
  // Host imports, saves, render jobs, and artifact writes carry separate authority.
  apply_lut: ["edit", "filesystem"],
  consolidate_and_transfer: ["edit", "filesystem"],
  consolidate_duplicates: ["edit", "filesystem"],
  create_project: ["edit", "filesystem"],
  open_project: ["edit", "filesystem"],
  save_project: ["edit", "filesystem"],
  save_project_as: ["edit", "filesystem"],
  save_project_uxp: ["edit", "filesystem"],
  import_ae_comps: ["edit", "filesystem"],
  import_edl: ["edit", "filesystem"],
  import_fcp_xml: ["edit", "filesystem"],
  import_folder: ["edit", "filesystem"],
  import_image_sequence: ["edit", "filesystem"],
  import_media: ["edit", "filesystem"],
  import_mogrt: ["edit", "filesystem"],
  // Places MOGRT clips read from disk; may also read a plan or transcript file.
  add_caption_graphics: ["edit", "filesystem"],
  // Uploads an audio or video file to a third-party engine and writes the transcript file; a sequence source may export it. Every source (media_path too) needs the full set: the file leaves the machine.
  transcribe_audio: ["inspect", "export", "filesystem"],
  import_mogrt_from_library: ["edit", "filesystem"],
  import_sequences: ["edit", "filesystem"],
  import_transcript_uxp: ["edit", "filesystem"],
  relink_media: ["edit", "filesystem"],
  relink_offline_media_uxp: ["edit", "filesystem"],
  export_aaf: ["edit", "export", "filesystem"],
  export_aaf_uxp: ["edit", "export", "filesystem"],
  export_as_fcp_xml: ["edit", "export", "filesystem"],
  export_as_project: ["edit", "export", "filesystem"],
  export_frame: ["edit", "export", "filesystem"],
  export_frame_uxp: ["edit", "export", "filesystem"],
  export_interchange_uxp: ["edit", "export", "filesystem"],
  export_omf: ["edit", "export", "filesystem"],
  export_sequence: ["edit", "export", "filesystem"],
  export_sequence_clip_review_frames: ["edit", "export", "filesystem"],
  export_sequence_marker_review_frames: ["edit", "export", "filesystem"],
  export_sequence_review_frames: ["edit", "export", "filesystem"],
  capture_frame: ["edit", "export", "filesystem"],
  encode_file: ["edit", "export", "filesystem"],
  encode_project_item: ["edit", "export", "filesystem"],
  start_batch_encode: ["edit", "export", "filesystem"],
  export_sequence_edl: ["export", "filesystem"],
  validate_export_preset: ["export", "filesystem"],
  freeze_frame: ["edit", "filesystem"],
  set_clip_duration: ["edit", "filesystem"],
  create_sequence_with_preset_uxp: ["edit", "filesystem"],
  delete_preview_files: ["edit", "filesystem"],
  refresh_media: ["edit", "filesystem"],
  get_encoder_presets: ["inspect", "filesystem"],
  list_stock_titles: ["inspect", "filesystem"],
  get_project_scratch_disks: ["inspect", "filesystem"],
  inspect_project_recovery: ["inspect", "filesystem"],
  plan_silence_review_markers: ["inspect", "filesystem"],
  validate_project_for_export: ["inspect", "filesystem"],
  create_context_edit_plan: ["inspect", "filesystem"],
  create_editorial_context_pack: ["inspect", "filesystem"],
  create_editorial_plan: ["inspect", "filesystem"],
  preview_editorial_plan: ["inspect", "filesystem"],
  inspect_film_editorial_workflow: ["inspect", "filesystem"],
  apply_editorial_organization_plan: ["inspect", "edit", "filesystem"],
  audit_object_masks_uxp: ["inspect"],
  has_transcript_uxp: ["inspect"],
  is_language_pack_available_uxp: ["inspect"],
  wait_for_host_readiness_uxp: ["inspect"],

  start_local_analysis_job: ["filesystem"],
  cancel_workflow_job: ["filesystem"],
  export_and_verify: ["inspect", "edit", "export", "filesystem"],
  inspect_rendered_video_scopes: ["inspect", "filesystem"],
  build_edit_review_evidence: ["inspect", "filesystem"],
  inspect_otio_interchange: ["inspect", "filesystem"],
  inspect_interchange_artifact: ["inspect", "filesystem"],
  inspect_interchange_loss_report: ["inspect", "filesystem"],
  preview_facility_metadata_intake: ["inspect", "filesystem"],
  export_review_markers: ["export", "filesystem"],
  export_facility_metadata_table: ["export", "filesystem"],
  verify_temporal_render_artifact: ["inspect", "filesystem"],
  build_project_handoff_manifest: ["inspect", "filesystem"],
  save_workflow_checkpoint: ["filesystem"],
  inspect_workflow_checkpoint: ["inspect", "filesystem"],
  acknowledge_operation_recovery: ["inspect", "edit"],
  apply_extended_edit_plan: ["inspect", "edit", "filesystem"],
  prepare_transcript_workflow: ["inspect", "filesystem"],
  // Audit is read-only; apply: true adds edit (see capabilitiesForToolInvocation).
  audit_project_structure: ["inspect"],
  preview_scene_review_workflow: ["inspect", "filesystem"],
  apply_scene_review_workflow: ["inspect", "edit", "filesystem"],
  // Decodes the source file with ffmpeg, writes a new still, then imports/places it.
  create_source_freeze_frame: ["inspect", "edit", "filesystem"],
  // Source bounds read the underlying media file through ffprobe.
  trim_clip: ["edit", "filesystem"],
  slip_edit: ["edit", "filesystem"],
  // Preset preflight reads local files; AME queue handoff can start exports.
  create_sequence: ["edit", "filesystem"],
  create_sequence_from_preset: ["edit", "filesystem"],
  add_to_render_queue: ["edit", "export", "filesystem"],
  export_sequence_job_start: ["edit", "export", "filesystem"],
  // Reads the job output file size to judge whether the export settled.
  get_export_job_status: ["inspect", "filesystem"],
  get_export_file_extension: ["inspect", "filesystem"],
  roll_edit: ["inspect", "edit", "filesystem"],
  slide_edit: ["inspect", "edit", "filesystem"],
  preview_after_effects_render_handoff: ["inspect", "filesystem"],
  apply_after_effects_render_handoff: ["inspect", "edit", "filesystem"],
  preview_send_clip_to_after_effects: ["inspect", "filesystem"],
  apply_send_clip_to_after_effects: ["inspect", "edit", "filesystem"],
  verify_after_effects_connection: ["inspect"],
  preview_mogrt_recipe: ["inspect", "filesystem"],
  create_mogrt_recipe: ["edit", "export", "filesystem"],
  verify_mogrt_artifact: ["inspect", "filesystem"],
  validate_mogrt_brand_kit: ["inspect", "filesystem"],
  preview_mogrt_batch: ["inspect", "filesystem"],
  create_mogrt_batch: ["edit", "export", "filesystem"],
  inspect_after_effects_template_source: ["inspect"],
  preview_mogrt_library_publish: ["inspect", "filesystem"],
  publish_mogrt_to_library: ["filesystem"],
  inspect_mogrt_library: ["inspect", "filesystem"],
  inspect_after_effects_render_templates: ["inspect"],
  preview_after_effects_render: ["inspect", "filesystem"],
  enqueue_after_effects_render: ["edit", "export", "filesystem"],
  preview_mogrt_premiere_handoff: ["inspect", "filesystem"],
  apply_mogrt_premiere_handoff: ["edit", "filesystem"],
  // Premiere writes XMP changes into the source media file on disk (verified:
  // set_xmp_metadata rewrote a user's MP4 metadata block), so this is a file write.
  set_xmp_metadata: ["edit", "filesystem"],
  // Changes the project and writes files: add_title bakes a .mogrt copy under
  // the user's app-data folder; the scratch-disk setters point Premiere at
  // folders it will write to and can save the project to verify them.
  add_title: ["edit", "filesystem"],
  set_project_scratch_disk: ["edit", "filesystem"],
  set_scratch_disk_path: ["edit", "filesystem"],
};

const ACTION_CAPABILITIES: Readonly<Record<string, Readonly<Record<string, readonly Capability[]>>>> = {
  manage_proxies: {
    create: ["edit", "export", "filesystem"],
    attach: ["edit", "filesystem"],
    toggle: ["edit"],
  },
  manage_project_sessions_uxp: {
    list: ["inspect"],
    validate: ["inspect", "filesystem"],
    create: ["edit", "filesystem"],
    open: ["edit", "filesystem"],
    save: ["edit", "filesystem"],
    save_as: ["edit", "filesystem"],
    branch_copies: ["edit", "filesystem"],
    close: ["edit", "filesystem"],
  },
  create_caption_track: {
    import: ["edit"],
    import_plan: ["edit", "filesystem"],
    plan_lecture_workflow: ["inspect"],
  },
  manage_growing_media_uxp: {
    status: ["inspect"],
    pause: ["edit"],
    resume: ["edit"],
  },
  manage_workflow_checkpoints_uxp: {
    has: ["inspect"],
    get: ["inspect"],
    set: ["edit"],
    clear: ["edit"],
  },
  maintain_media_health_uxp: {
    inspect: ["inspect"],
    refresh: ["edit", "filesystem"],
    set_offline: ["edit"],
    find_by_media_path: ["inspect"],
  },
  manage_source_media_timing_uxp: {
    inspect: ["inspect"],
    set_start: ["edit"],
  },
  manage_source_media_overrides_uxp: {
    inspect: ["inspect"],
    update: ["edit"],
  },
  manage_track_state_uxp: {
    inspect: ["inspect"],
    set_mute: ["edit"],
  },
  duplicate_track_item_uxp: {
    inspect: ["inspect"],
    apply: ["edit"],
  },
  ripple_delete_track_item_uxp: {
    inspect: ["inspect"],
    apply: ["edit"],
  },
  slide_track_item_uxp: {
    inspect: ["inspect"],
    apply: ["edit"],
  },
  slip_track_item_uxp: {
    inspect: ["inspect"],
    apply: ["edit"],
  },
  copy_clips_between_sequences_uxp: {
    inspect: ["inspect"],
    apply: ["edit"],
  },
  unnest_sequence_uxp: {
    inspect: ["inspect"],
    apply: ["edit"],
  },
  manage_source_clip_uxp: {
    inspect: ["inspect"],
    update: ["edit"],
  },
  manage_sequence_preview_frame_uxp: {
    inspect: ["inspect"],
    update: ["edit"],
  },

  manage_project_context: {
    capture: ["inspect", "filesystem"],
    enrich: ["inspect", "filesystem"],
    status: ["inspect", "filesystem"],
    import_evidence: ["filesystem"],
    clear: ["filesystem"],
  },
  manage_clip_effects_uxp: {
    catalog: ["inspect"],
    inspect: ["inspect"],
    add: ["edit"],
    remove: ["edit"],
  },
  batch_selected_clips_uxp: {
    inspect: ["inspect"],
    add_effect: ["edit"],
    remove_effect: ["edit"],
  },
  manage_timeline_selection_uxp: {
    inspect: ["inspect"],
    inspect_targets: ["inspect"],
    replace: ["edit"],
    add: ["edit"],
    remove: ["edit"],
    clear: ["edit"],
  },
  manage_proxy_ingest_uxp: {
    inspect_proxy: ["inspect"],
    attach_proxy: ["edit", "filesystem"],
    get_ingest: ["inspect"],
    set_ingest: ["edit"],
  },
  manage_metadata_uxp: {
    get: ["inspect"],
    inspect_fields: ["inspect"],
    update: ["edit"],
    update_field: ["edit"],
  },
  inspect_project_panel_metadata_uxp: {
    panel: ["inspect"],
    item_columns: ["inspect"],
  },
  manage_project_panel_metadata_uxp: {
    inspect: ["inspect"],
    update: ["edit"],
  },
  create_project_metadata_field_uxp: {
    inspect: ["inspect"],
    create: ["edit"],
  },
  manage_color_conformance_uxp: {
    preflight: ["inspect"],
    update: ["edit"],
  },
  audition_source_monitor_uxp: {
    state: ["inspect"],
    open_project_item: ["edit"],
    open_file: ["edit", "filesystem"],
    set_position: ["edit"],
    play: ["edit"],
    close: ["edit"],
    close_all: ["edit"],
  },
  preflight_production_storage_uxp: {
    preflight: ["inspect"],
    configure_project: ["edit", "filesystem"],
  },
  inspect_project_selection_uxp: {
    views: ["inspect"],
    selection: ["inspect"],
  },
  manage_markers_uxp: {
    inspect: ["inspect"],
    add: ["edit"],
    update: ["edit"],
    remove: ["edit"],
    remove_many: ["edit"],
  },
  organize_project_items_uxp: {
    inspect_bin: ["inspect"],
    create_bin: ["edit"],
    create_smart_bin: ["edit"],
    rename: ["edit"],
    move: ["edit"],
    set_color: ["edit"],
    remove: ["edit"],
  },
  manage_sequence_settings_uxp: {
    get: ["inspect"],
    update: ["edit"],
  },
  manage_sequence_display_format_uxp: {
    inspect: ["inspect"],
    update: ["edit"],
  },
  manage_sequence_range_uxp: {
    inspect: ["inspect"],
    update: ["edit"],
  },
  manage_work_area_uxp: {
    inspect: ["inspect"],
    set: ["edit"],
  },
  manage_sequence_playhead_uxp: {
    inspect: ["inspect"],
    set: ["edit"],
  },
  manage_app_preferences_uxp: {
    inspect: ["inspect"],
    set: ["edit"],
  },
  manage_timeline_source_label_uxp: {
    inspect: ["inspect"],
    update: ["edit"],
  },
  import_project_media_uxp: {
    files: ["edit", "filesystem"],
    sequences: ["edit", "filesystem"],
    ae_comps: ["edit", "filesystem"],
    all_ae_comps: ["edit", "filesystem"],
  },
  automate_effect_parameters_uxp: {
    inspect: ["inspect"],
    inspect_point_value: ["inspect"],
    inspect_point_displacement: ["inspect"],
    inspect_color_value: ["inspect"],
    inspect_keyframe: ["inspect"],
    inspect_time_varying: ["inspect"],
    set_point_value: ["edit"],
    set_color_value: ["edit"],
    set_value: ["edit"],
    add_keyframe: ["edit"],
    remove_keyframe: ["edit"],
    remove_keyframe_range: ["edit"],
    set_interpolation: ["edit"],
    set_time_varying: ["edit"],
  },
  transform_track_item_uxp: {
    inspect: ["inspect"],
    update: ["edit"],
  },
  edit_timeline_uxp: {
    insert: ["edit"],
    overwrite: ["edit"],
    clone_selection: ["edit"],
    remove_selection: ["edit"],
    insert_mogrt_path: ["edit", "filesystem"],
    insert_mogrt_library: ["edit"],
  },
  manage_sequences_uxp: {
    inspect: ["inspect"],
    create_from_media: ["edit"],
    clone: ["edit"],
    subsequence: ["edit"],
    activate: ["edit"],
    open: ["edit"],
    close: ["edit"],
    delete: ["edit"],
  },
  encode_media_uxp: {
    preflight: ["inspect"],
    jobs: ["inspect"],
    wait: ["inspect"],
    sequence: ["edit", "export", "filesystem"],
    project_item: ["edit", "export", "filesystem"],
    file: ["edit", "export", "filesystem"],
  },
};

/** A conservative classification for centralized server registration. */
export function capabilityForTool(toolName: string): Capability {
  if (UNSAFE_TOOL_NAMES.has(toolName)) return "unsafe-script";
  if (/^(export_|validate_export_|start_batch_encode|add_to_render_queue|queue_|encode_|capture_frame)/.test(toolName)) return "export";
  if (/^(import_|relink_|create_project|open_project|save_|consolidate_)/.test(toolName)) return "filesystem";
  if (FILESYSTEM_TOOL_NAMES.has(toolName)) return "filesystem";
  if (INSPECT_TOOL_NAMES.has(toolName) || /^(get_|list_|inspect_|find_|check_|search_)/.test(toolName)) return "inspect";
  // Every remaining registered tool changes Premiere state. Defaulting to edit
  // keeps new tools fail-closed instead of silently bypassing the authority profile.
  return "edit";
}

/** Resolve authority at the action level for consolidated multi-action tools. */
export function capabilitiesForToolInvocation(toolName: string, args: unknown): readonly Capability[] {
  if (toolName === "audit_project_structure" && args && typeof args === "object" && (args as Record<string, unknown>).apply === true) return ["inspect", "edit"];
  // set_track_states with snapshot and no state field anywhere only reads the tracks back.
  if (toolName === "set_track_states" && args && typeof args === "object" && (args as Record<string, unknown>).snapshot === true) {
    const tracks = (args as Record<string, unknown>).tracks;
    const readOnly = Array.isArray(tracks) && tracks.length > 0 && tracks.every(track => track && typeof track === "object"
      && (track as Record<string, unknown>).muted === undefined && (track as Record<string, unknown>).solo === undefined && (track as Record<string, unknown>).locked === undefined);
    if (readOnly) return ["inspect"];
  }
  // An empty AE render queue only exposes template names through a briefly queued composition.
  if (toolName === "inspect_after_effects_render_templates" && args && typeof args === "object" && (args as Record<string, unknown>).allow_temporary_queue_item === true) return ["inspect", "edit"];
  // Inline caption retiming is pure computation; reading input_path or writing
  // output_path touches the local filesystem and needs that authority too.
  if (toolName === "retime_caption_file" && args && typeof args === "object" && ((args as Record<string, unknown>).input_path !== undefined || (args as Record<string, unknown>).output_path !== undefined)) return ["inspect", "filesystem"];
  // Caption planning and QA are pure computation unless they read or write workspace files.
  if (toolName === "plan_captions" || toolName === "check_captions" || toolName === "read_sequence_captions") {
    const record = args && typeof args === "object" && !Array.isArray(args) ? args as Record<string, unknown> : {};
    const exportOption = record.export && typeof record.export === "object" && !Array.isArray(record.export) ? record.export as Record<string, unknown> : undefined;
    const touchesFiles = record.transcript_path !== undefined || record.plan_output_path !== undefined || record.file_path !== undefined || record.plan_path !== undefined
      || (toolName === "plan_captions" ? exportOption?.output_path !== undefined : record.export !== undefined);
    return touchesFiles ? ["inspect", "filesystem"] : ["inspect"];
  }
  if (toolName === "prepare_transcript_workflow" && args && typeof args === "object" && (args as Record<string, unknown>).start_if_missing === true) return ["inspect", "edit", "filesystem"];
  const inputRecord = args && typeof args === "object" && !Array.isArray(args) ? args as Record<string, unknown> : undefined;
  if (toolName === "inspect_timeline_snapshot" && inputRecord?.output_path !== undefined) return ["inspect", "filesystem"];
  if (toolName === "export_sequence_edl" && inputRecord?.output_path === undefined) return ["export"];
  if (toolName === "close_project") return inputRecord?.save_first === false ? ["edit"] : ["edit", "filesystem"];
  if (toolName === "set_offline" && inputRecord?.offline === false) return ["edit", "filesystem"];
  if (toolName === "manage_project_sessions_uxp" && inputRecord?.action === "close" && inputRecord.save_before_close === false) return ["edit"];
  if (toolName === "manage_metadata_uxp" && ((inputRecord?.action === "update" && typeof inputRecord.xmp_metadata === "string") || (inputRecord?.action === "update_field" && inputRecord.packet === "xmp"))) return ["edit", "filesystem"];
  const actionMap = ACTION_CAPABILITIES[toolName];
  if (toolName === "set_metadata" && args && typeof args === "object" && (args as Record<string, unknown>).packet === "xmp") {
    // XMP field writes land in the source media file, not just the project.
    return ["edit", "filesystem"];
  }
  if (!actionMap) return TOOL_CAPABILITY_REQUIREMENTS[toolName] ?? [capabilityForTool(toolName)];
  const input = args && typeof args === "object" && !Array.isArray(args)
    ? args as Record<string, unknown>
    : undefined;
  const action = input?.action;
  const required = typeof action === "string" && Object.hasOwn(actionMap, action) ? actionMap[action] : undefined;
  if (toolName === "encode_media_uxp" && action === "preflight" && typeof input?.preset_file === "string") {
    return ["inspect", "filesystem"];
  }
  return required
    ? required
    : [capabilityForTool(toolName)];
}

/**
 * Whether any invocation of a tool can need more than inspect authority. Used
 * to decide which tool schemas advertise the server-wide idempotency_key; the
 * per-call decision still comes from capabilitiesForToolInvocation.
 */
export function toolMayChangeState(toolName: string): boolean {
  if (toolName === "inspect_timeline_snapshot") return true;
  // Argument-dependent escalations handled specially above.
  if (toolName === "plan_captions" || toolName === "check_captions" || toolName === "read_sequence_captions" || toolName === "export_interchange_uxp" || toolName === "prepare_transcript_workflow" || toolName === "set_metadata" || toolName === "audit_project_structure" || toolName === "retime_caption_file" || toolName === "inspect_after_effects_render_templates") return true;
  const actionMap = ACTION_CAPABILITIES[toolName];
  const candidates: (readonly Capability[])[] = actionMap
    ? [...Object.values(actionMap), [capabilityForTool(toolName)]]
    : [TOOL_CAPABILITY_REQUIREMENTS[toolName] ?? [capabilityForTool(toolName)]];
  if (toolName === "encode_media_uxp") candidates.push(["inspect", "filesystem"]);
  return candidates.some((required) => required.some((capability) => capability !== "inspect"));
}

/**
 * Tools that stay advertised under every profile, because they are how an
 * operator diagnoses a profile that is too narrow: get_capabilities reports the
 * active authority, and ping proves the bridge is alive. Withholding them makes
 * a misconfigured server look broken with no supported way to ask why.
 */
export const ALWAYS_LISTED_TOOL_NAMES = new Set(["ping", "get_capabilities"]);

/**
 * Whether a tool should appear in tools/list under the given profile.
 *
 * This is an advertising decision, not an enforcement one — guardToolHandler
 * remains the authority check at call time. Keeping the two separate means a
 * listing bug can never widen what a profile is actually allowed to do.
 */
export function isToolPermitted(
  toolName: string,
  config: CapabilityConfig,
): boolean {
  if (ALWAYS_LISTED_TOOL_NAMES.has(toolName)) return true;
  if (toolName === "set_track_states") return config.capabilities.has("inspect") || config.capabilities.has("edit");
  if (toolName === "export_sequence_edl") return config.capabilities.has("export");
  const exactRequirements = TOOL_CAPABILITY_REQUIREMENTS[toolName];
  if (exactRequirements) {
    return exactRequirements.every((capability) => config.capabilities.has(capability));
  }
  const actionMap = ACTION_CAPABILITIES[toolName];
  if (actionMap) {
    return Object.values(actionMap).some((required) => required.every((capability) => config.capabilities.has(capability)));
  }
  return config.capabilities.has(capabilityForTool(toolName));
}

export function guardToolHandler<TArgs, TResult>(
  toolName: string,
  handler: (args: TArgs) => Promise<TResult>,
  config: CapabilityConfig = resolveCapabilities(),
  createOperationId: () => string = randomUUID,
): (args: TArgs) => Promise<TResult> {
  return async (args: TArgs) => {
    const operationId = createOperationId();
    for (const required of capabilitiesForToolInvocation(toolName, args)) {
      requireCapability(config, required, operationId);
    }
    return handler(args);
  };
}
